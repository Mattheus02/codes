/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numeroprimo;
import java.util.Scanner;
/**
 *
 * @author Mattheus
 */
public class NumeroPrimo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int valor = 1;
       
        Scanner numero = new Scanner (System.in);
    
        System.out.print ("Informe o seu numero: ");
        valor = numero.nextInt();
        
        
        Boolean numeroPrimo = valor%1 !=0 ; 
    
        if (valor >= 1 && valor/valor==1 && numeroPrimo == true) { 
            System.out.println("O número informado é primo!");
        }else if (valor == 2) {
            System.out.println("O número informado é primo!");
        }else if (valor == 1000) {
            System.out.println("A entrada é igual ao limite superior aceitável!");
        }else if (valor == 1001) {
            System.out.println("A entrada é maior do que o limite superior aceitável!");
        }else if (valor == -1) {
            System.out.println("A entrada é menor do que o limite inferior aceitável!");
        }else if (valor == 0) {
            System.out.println("A entrada é igual ao limite inferior aceitável!");
        }else if (valor == 'a') {
            System.out.println("Teste de um tipo de dado diferente!");
        } else {
            System.out.println("O número informado NAO é primo.");
        }
        numero.close();
    }
    
}
