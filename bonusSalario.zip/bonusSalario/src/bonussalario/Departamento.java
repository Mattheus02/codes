/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bonussalario;

import java.util.Scanner;

/**
 *
 * @author Mattheus
 */
public class Departamento {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Scanner entrada = new Scanner(System.in); 

        double salario, venda, salarioFinal = 0, bonus = 2000;
        String cargo, funcionario, gerente;
        
        
               
        System.out.print("Qual seu salario : ");
        salario= input.nextInt();
        
        System.out.print("Qual valor de vendas : ");
        venda= input.nextInt();
        
        if(venda > 25000){
            salarioFinal = salario + bonus;
        }
        System.out.println("Qual seu cargo: \n 1 - Funcionario\n 2 - Gerente\n");
        int num = entrada.nextInt();
        switch (num){
            case 1:
                salarioFinal = salario;
                System.out.println("Você escolheu 1");
                break;
            case 2:
                salarioFinal = salario + bonus;
                System.out.println("Salario de gerente: "+salarioFinal);
                break;
        }        
        if (salario >= 150000){
            salarioFinal = salario + 1000;
        }
        
        System.out.println("valor do salario final ="+salarioFinal);

}
