/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quicksort;

import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author Mattheus
 */
public class QuickSort {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[]v = {13,19,9,5,12,8,7,4,11,2,6,21};
        quicksort(v, 0, v.length-1);
        System.out.println(Arrays.toString(v));
    }
    
    
    private static void quicksort(int[] v, int esquerda, int direita){
        if(esquerda < direita){
            int d = separar(v, esquerda, direita);
            quicksort(v, esquerda, d-1);
            quicksort(v, d+1, direita);
        }
    }
    
    private static int separar(int[] v, int esquerda, int direita){
        int e = esquerda + 1;
        int d = direita;
        int pivo = v[esquerda];
        while(e <= d){
            if(v[e] <= pivo) e++;
            else if(v[d] > pivo) d--;
            else if(e <= d){
                trocar(v, e, d);
                e++;
                d--;
            }
        }
        trocar(v, esquerda, d);
        return d;
    }
    
    private static void trocar(int[] v, int e, int d){
        int aux = v[e];
        v[e] = v[d];
        v[d] = aux;
    }
}
