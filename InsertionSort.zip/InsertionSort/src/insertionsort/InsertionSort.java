/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insertionsort;

/**
 *
 * @author Mattheus
 */
public class InsertionSort {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int arr[] = new int[30];
        int i = 0; 
        
        while(arr.length > 1){
            arr[i] = 1 + (int) (Math.random()*100);
            i++;
        }
        
        InsertionSort ob = new InsertionSort();
        ob.sort(arr);
        
        printArray(arr);
    }
    
    void sort(int arr[]){
        int troca = 0;
        int n = arr.length;
        
        for(int i = 1; i < n; ++i){
            int key = arr[i];
            int j = i-1;
            while(j>= 0 && arr[j] > key){
                arr[j+1] = arr[j];
                j = j - 1;
                troca = troca + 1;
            }
            arr[j + 1] = key;
        }
        System.out.println("Número de Trocas = "+ troca);
    }
    
    static void printArray(int arr[]){
        int n = arr.length;
        for(int i = 0; i < n; ++i){
            System.out.println(arr[i] + " ");
        }
    }
    
}
