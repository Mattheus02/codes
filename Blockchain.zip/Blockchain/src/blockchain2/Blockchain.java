/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blockchain2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Mattheus
 */
public class Blockchain {
    
    public static void main(String[] args) {
    Scanner entrada = new Scanner(System.in);
    System.out.print("Digite o nome: ");
    String nome = entrada.nextLine();
    System.out.print("Digite a cidade: ");
    String cidade = entrada.nextLine(); 
    System.out.println();
    System.out.println("Nome: " + nome);
    System.out.println("Cidade: " + cidade);
    entrada.close();
  }
    
    private int difficulty;
    private List <Block> blocks;
    
    public Blockchain(int difficulty){
        //Iniciando bloco gênesis.
        this.difficulty = difficulty;
        blocks = new ArrayList<>();
        
        Block x = new Block(0, System.currentTimeMillis(), null, "Primeiro bloco");
        x.minerarBloco(difficulty);
        
        blocks.add(x);
    }

    
    public int getDifficulty(){
        return difficulty;
    }
    
    public Block ultimoBloco(){
        return blocks.get(blocks.size()-1);
    }
    
    public Block novoBloco(String dado){
        Block ultimoBloco = ultimoBloco();
        return new Block (ultimoBloco.getIndex()+1, System.currentTimeMillis(), ultimoBloco.getHash(), dado);
    }
    
    public void addBloco (Block x){
        if(x !=null){
            x.minerarBloco(difficulty);
            blocks.add(x);
        }
    }
    
    public boolean validaGenesis(){
        Block primeiroBloco = blocks.get(0);
        
        if(primeiroBloco.getIndex() != 0){
            return false;
        }
        
        if(primeiroBloco.getHashAnt() != null){
            return false;
        }
        
        if(primeiroBloco.getHash() == null || !Block.calculaHash(primeiroBloco).equals(primeiroBloco.getHash())){
            return false;
        }
        
        return true;
    }
    
    public boolean validaNovoBloco(Block novoBloco, Block blocoAnt){
        if(novoBloco != null && blocoAnt != null){
            if(blocoAnt.getIndex()+1 != novoBloco.getIndex()){
                return false;
            }
            
            if(novoBloco.getHashAnt() == null || !novoBloco.getHashAnt().equals(blocoAnt.getHash())){
                return false;
            }
            
            if(novoBloco.getHash() == null || !novoBloco.calculaHash(novoBloco).equals(novoBloco.getHash())){
                return false;
            }
            return true;
        }
        return false;
    }
    
    public boolean validaBlockChain(){
        if(!validaGenesis()){
            return false;
        }
        
        for(int i = 1; i < blocks.size(); i++){
            Block blocoAtual = blocks.get(i);
            Block blocoAnt = blocks.get(i-1);
            
            if(!validaNovoBloco(blocoAtual, blocoAnt)){
                return false;
            }
        }
        return true;
    }
    
    public String toString(){
        StringBuilder strBuilder = new StringBuilder();
        
        for(Block bloco: blocks){
            strBuilder.append(bloco).append("\n");
        }
        return strBuilder.toString();
    }  
}
