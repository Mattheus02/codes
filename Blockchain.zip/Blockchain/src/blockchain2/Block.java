/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blockchain2;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;

/**
 *
 * @author Mattheus
 */
public class Block {
    
    private int index;
    private long timeStamp;
    private String hash;
    private String hashAnt;
    private String dado;
    private int nonce;
    
    public Block(int index, long timeStamp, String hashAnt, String dado){
        super();
        this.index = index;
        this.timeStamp = timeStamp;
        this.hashAnt = hashAnt;
        this.dado = dado;
        nonce = 0;
        hash = Block.calculaHash(this);
    }

    public int getIndex() {
        return index;
    }

    public long getTimeStamp() {
        return timeStamp;
    }

    public String getHash() {
        return hash;
    }

    public String getHashAnt() {
        return hashAnt;
    }

    public String getDado() {
        return dado;
    }
    
    private String str(){
        return index + timeStamp + hashAnt + dado + nonce;
    }
    
  
    public String toString(){
        StringBuilder strBuilder = new StringBuilder();
        strBuilder.append("\n").append("\n").append("Bloco ").append(index).append("\n")
        .append("Dados Usuário: ").append(dado).append("\n")
        .append("Momento de criação: ").append(new Date(timeStamp)).append("\n")        
        .append("Hash: ").append(hash).append("\n")
        .append("Hash Anterior: ").append(hashAnt).append(";");
        return strBuilder.toString();
    }
    
    public static String calculaHash(Block block){
        if(block != null){
            MessageDigest digest = null;
            try{
                digest = MessageDigest.getInstance("SHA-256");
            }catch (NoSuchAlgorithmException e){
                return null;
            }
            
            String txt = block.str();
            final byte bytes [] = digest.digest(txt.getBytes());
            final StringBuilder strBuilder = new StringBuilder();
            
            for(final byte x: bytes){
                String hex = Integer.toHexString(0xff & x);
                
                if(hex.length()== 1){
                    strBuilder.append('0');
                }
                strBuilder.append(hex);
            }
            return strBuilder.toString();
        }
        return null;
    }
    
    public void minerarBloco(int difficulty){
        nonce = 4;
        
        while(!getHash().substring(0, difficulty).equals(Utils.zeros(difficulty))){
            nonce ++;
            hash = Block.calculaHash(this);
        }
    }
    
}
