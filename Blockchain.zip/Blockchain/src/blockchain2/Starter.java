/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blockchain2;

/**
 *
 * @author Mattheus
 */
public class Starter {
    
    public static void main(String[] args){
        
        Blockchain blockchain = new Blockchain (4);
        blockchain.addBloco(blockchain.novoBloco("Segundo Bloco"));
        blockchain.addBloco(blockchain.novoBloco("Terceiro Bloco"));
        blockchain.addBloco(blockchain.novoBloco("Quarto Bloco"));
        blockchain.addBloco(blockchain.novoBloco("Quinto Bloco"));
        blockchain.addBloco(blockchain.novoBloco("Sexto Bloco"));
        blockchain.addBloco(blockchain.novoBloco("Sétimo Bloco"));
        blockchain.addBloco(blockchain.novoBloco("Oitavo Bloco"));
        blockchain.addBloco(blockchain.novoBloco("Nono Bloco"));
        blockchain.addBloco(blockchain.novoBloco("Décimo Bloco"));
        
        
        System.out.println(blockchain);
    }
    
}
